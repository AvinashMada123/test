import axios from 'axios';
import { getFoodNutritionData } from './nutritionData';

// Google Cloud Vision API key
const API_KEY = 'AIzaSyDQDY9Q98RCPMJPe6bBih_0qnlVAaHg3lc';
const VISION_API_URL = `https://vision.googleapis.com/v1/images:annotate?key=${API_KEY}`;

/**
 * Convert a base64 image to the format expected by the Vision API
 * @param {string} imageData - Base64 image data
 * @returns {string} - Formatted image data
 */
const formatImageData = (imageData) => {
  // If it's a data URL, we need to strip the prefix
  if (imageData.startsWith('data:image')) {
    return imageData.split(',')[1];
  }
  return imageData;
};

/**
 * Send image to Vision API and get food identification
 * @param {string} imageData - Base64 image data 
 * @returns {Promise<Object>} - Food analysis results
 */
export const analyzeFood = async (imageData) => {
  try {
    // Simulate a slight delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const formattedImage = formatImageData(imageData);
    
    const requestBody = {
      requests: [
        {
          image: {
            content: formattedImage
          },
          features: [
            {
              type: 'LABEL_DETECTION',
              maxResults: 10
            },
            {
              type: 'WEB_DETECTION',
              maxResults: 10
            }
          ]
        }
      ]
    };
    
    const response = await axios.post(VISION_API_URL, requestBody);
    
    // Extract food labels
    const labelAnnotations = response.data.responses[0].labelAnnotations || [];
    const webEntities = response.data.responses[0].webDetection?.webEntities || [];
    
    // Filter for food-related labels
    const foodLabels = labelAnnotations.filter(label => {
      const description = label.description.toLowerCase();
      return isFoodRelated(description);
    });
    
    // If no food labels found, check web entities
    if (foodLabels.length === 0) {
      const foodEntities = webEntities.filter(entity => {
        if (!entity.description) return false;
        const description = entity.description.toLowerCase();
        return isFoodRelated(description);
      });
      
      if (foodEntities.length === 0) {
        throw new Error("We couldn't identify any food in this image. Please try with a clearer photo.");
      }
      
      // Get nutrition data for the top food entity
      const topFoodEntity = foodEntities[0];
      const foodName = topFoodEntity.description;
      const confidence = topFoodEntity.score || 0.7;
      
      // Get nutrition data
      const nutritionData = getFoodNutritionData(foodName);
      
      // Get all alternative foods
      const allPossibleFoods = foodEntities.map(entity => {
        const altFoodName = entity.description;
        const altNutritionData = getFoodNutritionData(altFoodName);
        return {
          foodName: altFoodName,
          confidence: entity.score || 0.5,
          calories: altNutritionData.calories,
          macros: altNutritionData.macros
        };
      });
      
      return {
        foodName,
        confidence,
        calories: nutritionData.calories,
        macros: nutritionData.macros,
        allPossibleFoods
      };
    }
    
    // Get the top food label
    const topFoodLabel = foodLabels[0];
    const foodName = topFoodLabel.description;
    const confidence = topFoodLabel.score;
    
    // Get nutrition data
    const nutritionData = getFoodNutritionData(foodName);
    
    // Get all possible foods
    const allPossibleFoods = foodLabels.map(label => {
      const altFoodName = label.description;
      const altNutritionData = getFoodNutritionData(altFoodName);
      return {
        foodName: altFoodName,
        confidence: label.score,
        calories: altNutritionData.calories,
        macros: altNutritionData.macros
      };
    });
    
    return {
      foodName,
      confidence,
      calories: nutritionData.calories,
      macros: nutritionData.macros,
      allPossibleFoods
    };
  } catch (error) {
    console.error('Error analyzing food image:', error);
    throw new Error(error.message || 'Failed to analyze the food image. Please try again.');
  }
};

/**
 * Check if a label is food related
 * @param {string} label - The label to check
 * @returns {boolean} - Whether the label is food related
 */
const isFoodRelated = (label) => {
  const foodKeywords = [
    'food', 'meal', 'dish', 'cuisine', 'breakfast', 'lunch', 'dinner',
    'snack', 'fruit', 'vegetable', 'meat', 'dessert', 'bread', 'pasta',
    'rice', 'salad', 'sandwich', 'soup', 'stew', 'fish', 'seafood',
    'chicken', 'beef', 'pork', 'vegetarian', 'vegan', 'cheese', 'dairy',
    'appetizer', 'side dish', 'cake', 'cookie', 'pie', 'drink', 'beverage'
  ];
  
  return foodKeywords.some(keyword => label.includes(keyword));
};