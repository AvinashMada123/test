import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Auth related functions
export const signUp = async (email, password) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });
  
  if (error) throw error;
  return data;
};

export const signIn = async (email, password) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) throw error;
  return data;
};

export const signOut = async () => {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
};

export const getCurrentUser = async () => {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  return data?.user || null;
};

// Scan history related functions
export const saveScanResult = async (userId, scanResult) => {
  const { data, error } = await supabase
    .from('scan_history')
    .insert([
      { 
        user_id: userId,
        food_name: scanResult.foodName,
        confidence: scanResult.confidence,
        calories: scanResult.calories,
        protein: scanResult.macros.protein,
        carbs: scanResult.macros.carbs,
        fat: scanResult.macros.fat,
        image_url: scanResult.imageUrl || null,
        possible_foods: scanResult.allPossibleFoods || []
      }
    ])
    .select();
  
  if (error) throw error;
  return data;
};

export const getUserScanHistory = async (userId) => {
  const { data, error } = await supabase
    .from('scan_history')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return data;
};

export const deleteScanResult = async (scanId) => {
  const { error } = await supabase
    .from('scan_history')
    .delete()
    .eq('id', scanId);
  
  if (error) throw error;
  return true;
};