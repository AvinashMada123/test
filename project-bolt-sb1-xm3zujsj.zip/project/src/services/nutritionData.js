/**
 * Nutrition database for common foods
 * Values are approximated for a standard serving
 */
const nutritionDatabase = {
  // Fruits
  'apple': { calories: 95, macros: { protein: 0.5, carbs: 25, fat: 0.3 } },
  'banana': { calories: 105, macros: { protein: 1.3, carbs: 27, fat: 0.4 } },
  'orange': { calories: 62, macros: { protein: 1.2, carbs: 15, fat: 0.2 } },
  'strawberry': { calories: 50, macros: { protein: 1, carbs: 12, fat: 0.5 } },
  'grapes': { calories: 104, macros: { protein: 1.1, carbs: 27, fat: 0.2 } },
  'watermelon': { calories: 46, macros: { protein: 0.9, carbs: 11.5, fat: 0.2 } },
  'pineapple': { calories: 82, macros: { protein: 0.9, carbs: 22, fat: 0.2 } },
  'mango': { calories: 99, macros: { protein: 1.4, carbs: 25, fat: 0.6 } },
  'fruit': { calories: 80, macros: { protein: 1, carbs: 20, fat: 0.3 } },

  // Vegetables
  'broccoli': { calories: 55, macros: { protein: 3.7, carbs: 11, fat: 0.6 } },
  'carrot': { calories: 50, macros: { protein: 1.2, carbs: 12, fat: 0.3 } },
  'spinach': { calories: 23, macros: { protein: 2.9, carbs: 3.6, fat: 0.4 } },
  'lettuce': { calories: 15, macros: { protein: 1.4, carbs: 2.9, fat: 0.2 } },
  'tomato': { calories: 22, macros: { protein: 1.1, carbs: 4.8, fat: 0.2 } },
  'potato': { calories: 163, macros: { protein: 4.3, carbs: 37, fat: 0.2 } },
  'cucumber': { calories: 16, macros: { protein: 0.7, carbs: 3.6, fat: 0.1 } },
  'onion': { calories: 40, macros: { protein: 1.1, carbs: 9.3, fat: 0.1 } },
  'vegetable': { calories: 45, macros: { protein: 2, carbs: 10, fat: 0.3 } },

  // Proteins
  'chicken': { calories: 239, macros: { protein: 27, carbs: 0, fat: 14 } },
  'beef': { calories: 250, macros: { protein: 26, carbs: 0, fat: 17 } },
  'fish': { calories: 206, macros: { protein: 22, carbs: 0, fat: 12 } },
  'egg': { calories: 78, macros: { protein: 6.3, carbs: 0.6, fat: 5.3 } },
  'salmon': { calories: 208, macros: { protein: 20, carbs: 0, fat: 13 } },
  'tuna': { calories: 179, macros: { protein: 39, carbs: 0, fat: 1 } },
  'shrimp': { calories: 99, macros: { protein: 24, carbs: 0, fat: 0.3 } },
  'pork': { calories: 242, macros: { protein: 26, carbs: 0, fat: 14 } },
  'tofu': { calories: 94, macros: { protein: 10, carbs: 2, fat: 6 } },
  'beans': { calories: 127, macros: { protein: 8.7, carbs: 22.8, fat: 0.5 } },
  'meat': { calories: 230, macros: { protein: 26, carbs: 0, fat: 15 } },

  // Grains
  'rice': { calories: 206, macros: { protein: 4.3, carbs: 45, fat: 0.4 } },
  'bread': { calories: 265, macros: { protein: 9, carbs: 49, fat: 3.2 } },
  'pasta': { calories: 221, macros: { protein: 8.1, carbs: 43, fat: 1.3 } },
  'cereal': { calories: 379, macros: { protein: 11, carbs: 68, fat: 7 } },
  'oats': { calories: 389, macros: { protein: 16.9, carbs: 66, fat: 6.9 } },
  'quinoa': { calories: 222, macros: { protein: 8.1, carbs: 39, fat: 3.6 } },
  'grain': { calories: 260, macros: { protein: 9, carbs: 51, fat: 3 } },

  // Dairy
  'milk': { calories: 149, macros: { protein: 7.7, carbs: 12, fat: 8 } },
  'cheese': { calories: 402, macros: { protein: 25, carbs: 2.4, fat: 33 } },
  'yogurt': { calories: 154, macros: { protein: 3.6, carbs: 17, fat: 8.6 } },
  'butter': { calories: 717, macros: { protein: 0.9, carbs: 0.1, fat: 81 } },
  'ice cream': { calories: 207, macros: { protein: 3.5, carbs: 23, fat: 11 } },
  'dairy': { calories: 180, macros: { protein: 8, carbs: 11, fat: 13 } },

  // Fast Food
  'pizza': { calories: 266, macros: { protein: 11, carbs: 33, fat: 10 } },
  'hamburger': { calories: 295, macros: { protein: 17, carbs: 30, fat: 14 } },
  'french fries': { calories: 365, macros: { protein: 3.4, carbs: 48, fat: 17 } },
  'hot dog': { calories: 290, macros: { protein: 11, carbs: 31, fat: 15 } },
  'taco': { calories: 210, macros: { protein: 9.2, carbs: 21, fat: 10 } },
  'burrito': { calories: 378, macros: { protein: 14, carbs: 56, fat: 11 } },
  'fried chicken': { calories: 310, macros: { protein: 20, carbs: 8.1, fat: 21 } },
  'sandwich': { calories: 290, macros: { protein: 15, carbs: 35, fat: 9 } },
  'fast food': { calories: 310, macros: { protein: 15, carbs: 33, fat: 14 } },

  // Desserts
  'cake': { calories: 371, macros: { protein: 5.2, carbs: 74, fat: 5.2 } },
  'cookie': { calories: 488, macros: { protein: 6.1, carbs: 64, fat: 23 } },
  'ice cream': { calories: 207, macros: { protein: 3.5, carbs: 23, fat: 11 } },
  'chocolate': { calories: 546, macros: { protein: 4.9, carbs: 61, fat: 31 } },
  'donut': { calories: 412, macros: { protein: 4.5, carbs: 51, fat: 22 } },
  'pastry': { calories: 410, macros: { protein: 5.2, carbs: 52, fat: 21 } },
  'muffin': { calories: 340, macros: { protein: 5, carbs: 55, fat: 11 } },
  'dessert': { calories: 390, macros: { protein: 5, carbs: 60, fat: 15 } },

  // Beverages
  'coffee': { calories: 2, macros: { protein: 0.3, carbs: 0, fat: 0 } },
  'tea': { calories: 2, macros: { protein: 0, carbs: 0.5, fat: 0 } },
  'soda': { calories: 140, macros: { protein: 0, carbs: 39, fat: 0 } },
  'juice': { calories: 112, macros: { protein: 0.5, carbs: 26, fat: 0.3 } },
  'smoothie': { calories: 175, macros: { protein: 2.5, carbs: 40, fat: 0.7 } },
  'water': { calories: 0, macros: { protein: 0, carbs: 0, fat: 0 } },
  'beer': { calories: 154, macros: { protein: 1.6, carbs: 13, fat: 0 } },
  'wine': { calories: 123, macros: { protein: 0.1, carbs: 3.8, fat: 0 } },
  'beverage': { calories: 100, macros: { protein: 0.5, carbs: 20, fat: 0.1 } },

  // Meals
  'salad': { calories: 150, macros: { protein: 5, carbs: 15, fat: 8 } },
  'soup': { calories: 170, macros: { protein: 7, carbs: 22, fat: 6 } },
  'stew': { calories: 190, macros: { protein: 12, carbs: 18, fat: 9 } },
  'curry': { calories: 243, macros: { protein: 10, carbs: 19, fat: 15 } },
  'stir fry': { calories: 250, macros: { protein: 15, carbs: 23, fat: 10 } },
  'casserole': { calories: 274, macros: { protein: 16, carbs: 25, fat: 12 } },
  'pasta dish': { calories: 350, macros: { protein: 13, carbs: 52, fat: 10 } },
  'breakfast': { calories: 450, macros: { protein: 18, carbs: 50, fat: 20 } },
  'lunch': { calories: 550, macros: { protein: 25, carbs: 60, fat: 22 } },
  'dinner': { calories: 650, macros: { protein: 30, carbs: 65, fat: 28 } },
  'meal': { calories: 550, macros: { protein: 25, carbs: 60, fat: 22 } },
  'dish': { calories: 300, macros: { protein: 15, carbs: 35, fat: 12 } },
  'cuisine': { calories: 450, macros: { protein: 20, carbs: 55, fat: 18 } },
  'food': { calories: 350, macros: { protein: 15, carbs: 45, fat: 12 } },

  // Default
  'default': { calories: 250, macros: { protein: 10, carbs: 30, fat: 10 } }
};

/**
 * Get nutrition data for a food item
 * @param {string} foodName - The name of the food
 * @returns {Object} - Nutrition data including calories and macros
 */
export const getFoodNutritionData = (foodName) => {
  if (!foodName) return nutritionDatabase.default;
  
  // Convert to lowercase for case-insensitive matching
  const lowercaseFoodName = foodName.toLowerCase();
  
  // Check for exact match
  if (nutritionDatabase[lowercaseFoodName]) {
    return nutritionDatabase[lowercaseFoodName];
  }
  
  // Check for partial matches
  for (const key of Object.keys(nutritionDatabase)) {
    if (lowercaseFoodName.includes(key) || key.includes(lowercaseFoodName)) {
      return nutritionDatabase[key];
    }
  }
  
  // Return default if no match found
  return nutritionDatabase.default;
};

/**
 * Formats a nutrition value to display with the correct number of decimal places
 * @param {number} value - The nutrition value
 * @returns {number|string} - Formatted value
 */
export const formatNutritionValue = (value) => {
  if (value === 0) return 0;
  if (value < 1) return value.toFixed(1);
  return Math.round(value);
};