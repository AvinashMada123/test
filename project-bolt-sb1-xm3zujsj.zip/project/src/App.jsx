import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import LandingScreen from './components/LandingScreen';
import ScannerSection from './components/ScannerSection';
import PreviewConfirm from './components/PreviewConfirm';
import LoadingState from './components/LoadingState';
import ResultsScreen from './components/ResultsScreen';
import ErrorMessage from './components/ErrorMessage';
import LoginForm from './components/auth/LoginForm';
import SignupForm from './components/auth/SignupForm';
import Dashboard from './components/dashboard/Dashboard';
import ScanHistory from './components/ScanHistory';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './routes/ProtectedRoute';
import PublicLayout from './routes/PublicLayout';
import ScanWorkflow from './components/ScanWorkflow';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50 text-gray-900">
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={<PublicLayout />}>
              <Route index element={<LandingScreen onGetStarted={() => {}} />} />
              <Route path="login" element={<LoginForm />} />
              <Route path="signup" element={<SignupForm />} />
            </Route>
            
            {/* Protected Routes */}
            <Route path="/" element={<ProtectedRoute />}>
              <Route path="dashboard" element={<Dashboard />} />
              <Route path="history" element={<ScanHistory />} />
              <Route path="new-scan" element={<ScanWorkflow />} />
            </Route>
            
            {/* Fallback route */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;