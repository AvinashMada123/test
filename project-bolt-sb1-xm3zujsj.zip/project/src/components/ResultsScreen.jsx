import React from 'react';
import { motion } from 'framer-motion';

function ResultsScreen({ results, onNewScan }) {
  if (!results) return null;
  
  const { foodName, confidence, calories, macros, allPossibleFoods } = results;
  
  // Animation variants
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };
  
  const barVariants = {
    hidden: { width: 0 },
    visible: width => ({ width: `${width}%` })
  };

  // Function to determine the percentage width for progress bars
  const getBarWidth = (macroGrams) => {
    const totalMacroGrams = macros.protein + macros.carbs + macros.fat;
    return Math.round((macroGrams / totalMacroGrams) * 100);
  };

  return (
    <div className="min-h-screen bg-gray-50 px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <motion.h1 
            className="text-2xl md:text-3xl font-bold"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
          >
            Your Results
          </motion.h1>
          
          <motion.button
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 btn-secondary"
            onClick={onNewScan}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            New Photo
          </motion.button>
        </div>
        
        <div className="grid md:grid-cols-2 gap-6">
          {/* Identification Card */}
          <motion.div 
            className="card p-6"
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            transition={{ duration: 0.4 }}
          >
            <h2 className="text-xl font-semibold mb-4 text-gray-800">Identified Food</h2>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-primary-100 rounded-xl flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-primary-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                </svg>
              </div>
              
              <div>
                <h3 className="text-2xl font-bold text-gray-900">{foodName}</h3>
                <p className="text-sm text-gray-500">{Math.round(confidence * 100)}% confidence</p>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h4 className="font-medium text-gray-700 mb-2">About this food</h4>
              <p className="text-gray-600 text-sm">
                We've identified this as {foodName} based on visual characteristics. The nutrition information provided is an estimate based on standard serving sizes.
              </p>
            </div>
            
            {allPossibleFoods && allPossibleFoods.length > 1 && (
              <div>
                <h4 className="font-medium text-gray-700 mb-3">Other possible identifications</h4>
                <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                  {allPossibleFoods.slice(1).map((food, index) => (
                    <div 
                      key={index} 
                      className="flex justify-between items-center p-2 border-b border-gray-100"
                    >
                      <span className="font-medium text-gray-800">{food.foodName}</span>
                      <div className="flex items-center">
                        <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden mr-2">
                          <div 
                            className="h-full bg-primary-500 rounded-full"
                            style={{ width: `${Math.round(food.confidence * 100)}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-500">{Math.round(food.confidence * 100)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
          
          {/* Macronutrient Card */}
          <motion.div 
            className="card p-6"
            variants={cardVariants}
            initial="hidden"
            animate="visible"
            transition={{ duration: 0.4, delay: 0.2 }}
          >
            <h2 className="text-xl font-semibold mb-4 text-gray-800">Nutrition Information</h2>
            
            <div className="mb-6">
              <p className="text-sm text-gray-500 mb-1">Calories</p>
              <p className="text-3xl font-bold text-gray-900">{calories} <span className="text-lg font-medium text-gray-600">kcal</span></p>
            </div>
            
            <div className="space-y-4">
              {/* Protein */}
              <div>
                <div className="flex justify-between mb-1">
                  <p className="text-sm font-medium text-gray-700">Protein</p>
                  <p className="text-sm font-medium text-gray-900">{macros.protein}g</p>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-primary-600 rounded-full"
                    custom={getBarWidth(macros.protein)}
                    variants={barVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ duration: 0.8, delay: 0.6 }}
                  />
                </div>
              </div>
              
              {/* Carbs */}
              <div>
                <div className="flex justify-between mb-1">
                  <p className="text-sm font-medium text-gray-700">Carbs</p>
                  <p className="text-sm font-medium text-gray-900">{macros.carbs}g</p>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-secondary-600 rounded-full"
                    custom={getBarWidth(macros.carbs)}
                    variants={barVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ duration: 0.8, delay: 0.8 }}
                  />
                </div>
              </div>
              
              {/* Fat */}
              <div>
                <div className="flex justify-between mb-1">
                  <p className="text-sm font-medium text-gray-700">Fat</p>
                  <p className="text-sm font-medium text-gray-900">{macros.fat}g</p>
                </div>
                <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-accent-600 rounded-full"
                    custom={getBarWidth(macros.fat)}
                    variants={barVariants}
                    initial="hidden"
                    animate="visible"
                    transition={{ duration: 0.8, delay: 1 }}
                  />
                </div>
              </div>
            </div>
            
            <p className="text-xs text-gray-500 mt-6 text-center">
              Nutrition values are estimated based on typical servings.
            </p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

export default ResultsScreen;