import React from 'react';
import { motion } from 'framer-motion';

function PreviewConfirm({ image, onAnalyze, onReset }) {
  return (
    <div className="min-h-screen flex flex-col items-center px-4 py-12">
      <motion.h1 
        className="text-3xl font-bold text-center mb-2"
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        Preview Your Food
      </motion.h1>
      
      <motion.p 
        className="text-gray-600 text-center mb-10 max-w-lg"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1, duration: 0.3 }}
      >
        Confirm the image looks good before analysis
      </motion.p>
      
      <motion.div 
        className="w-full max-w-md card overflow-hidden"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.4 }}
      >
        <div className="relative">
          <img 
            src={image} 
            alt="Selected food photo" 
            className="w-full object-cover aspect-square"
          />
          
          <button 
            className="absolute top-3 right-3 bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full transition duration-200"
            onClick={onReset}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        <div className="p-6">
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            className="btn-primary w-full"
            onClick={onAnalyze}
          >
            Analyze Food
          </motion.button>
          
          <p className="text-gray-500 text-sm text-center mt-4">
            Photos are processed securely; no copies are stored.
          </p>
        </div>
      </motion.div>
    </div>
  );
}

export default PreviewConfirm;