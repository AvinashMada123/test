import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

function ErrorMessage({ type, message, options, onSelectFood, onReset }) {
  const [selectedOption, setSelectedOption] = useState(null);
  const [isDismissing, setIsDismissing] = useState(false);
  
  useEffect(() => {
    let timer;
    
    if (type === 'error' && message) {
      timer = setTimeout(() => {
        setIsDismissing(true);
        setTimeout(onReset, 300);
      }, 4000);
    }
    
    return () => clearTimeout(timer);
  }, [type, message, onReset]);
  
  const handleConfirmSelection = () => {
    if (selectedOption) {
      onSelectFood(selectedOption);
    }
  };
  
  if (type === 'lowConfidence') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
        <motion.div 
          className="w-full max-w-md card p-6"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 bg-warning-50 rounded-full flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-warning-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
            
            <h2 className="text-xl font-semibold text-gray-800">
              We're not completely sure...
            </h2>
          </div>
          
          <p className="text-gray-600 mb-6">
            We couldn't identify your food with high confidence. Please select what best matches your image:
          </p>
          
          <div className="space-y-3 mb-6">
            {options.map((option, index) => (
              <label 
                key={index} 
                className={`flex items-center p-3 border rounded-lg cursor-pointer transition duration-200 ${
                  selectedOption && selectedOption.foodName === option.foodName 
                    ? 'border-primary-500 bg-primary-50' 
                    : 'border-gray-200 hover:border-primary-200'
                }`}
              >
                <input
                  type="radio"
                  name="foodOption"
                  className="mr-3 text-primary-600 focus:ring-primary-500"
                  checked={selectedOption && selectedOption.foodName === option.foodName}
                  onChange={() => setSelectedOption(option)}
                />
                <div>
                  <p className="font-medium">{option.foodName}</p>
                  <p className="text-sm text-gray-500">{option.calories} kcal per serving</p>
                </div>
              </label>
            ))}
          </div>
          
          <div className="flex gap-3">
            <button
              className="btn-secondary flex-1"
              onClick={onReset}
            >
              Try Again
            </button>
            
            <button
              className="btn-primary flex-1"
              disabled={!selectedOption}
              onClick={handleConfirmSelection}
            >
              Confirm
            </button>
          </div>
        </motion.div>
      </div>
    );
  }
  
  if (type === 'error') {
    return (
      <motion.div 
        className={`fixed bottom-4 left-1/2 transform -translate-x-1/2 max-w-md w-full bg-error-50 border-l-4 border-error-500 rounded-lg shadow-lg p-4 ${
          isDismissing ? 'opacity-0' : 'opacity-100'
        } transition-opacity duration-300`}
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex">
          <div className="flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-error-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div className="ml-3">
            <p className="text-sm text-error-700">
              {message || "Something went wrong. Please retry."}
            </p>
          </div>
          <div className="ml-auto pl-3">
            <div className="-mx-1.5 -my-1.5">
              <button
                className="inline-flex bg-error-50 rounded-md p-1.5 text-error-500 hover:bg-error-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-error-500"
                onClick={() => {
                  setIsDismissing(true);
                  setTimeout(onReset, 300);
                }}
              >
                <svg className="h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }
  
  return null;
}

export default ErrorMessage;