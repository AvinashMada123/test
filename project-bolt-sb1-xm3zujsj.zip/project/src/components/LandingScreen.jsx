import React from 'react';
import { motion } from 'framer-motion';

function LandingScreen({ onGetStarted }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <header className="text-center mb-12">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            <span className="text-primary-600">Snap</span> • 
            <span className="text-secondary-600">Identify</span> • 
            <span className="text-accent-600">Track</span>
          </h1>
          
          <p className="text-xl text-gray-700 max-w-2xl mx-auto">
            Instantly analyze what's on your plate with a single photo - calories and nutrition at a glance.
          </p>
        </motion.div>
      </header>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
        className="w-full max-w-md"
      >
        <div className="p-6 md:p-8 card">
          <div className="aspect-w-4 aspect-h-3 bg-gradient-to-br from-primary-100 to-primary-200 rounded-xl mb-6 flex items-center justify-center">
            <div className="p-8">
              <motion.svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-24 w-24 text-primary-600 mx-auto"
                viewBox="0 0 24 24"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5, duration: 0.8 }}
              >
                <path 
                  fill="currentColor" 
                  d="M12 9a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3m0 8a5 5 0 0 1-5-5 5 5 0 0 1 5-5 5 5 0 0 1 5 5 5 5 0 0 1-5 5m0-12.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5z" 
                />
              </motion.svg>
            </div>
          </div>

          <p className="text-gray-700 text-center mb-6">
            CalorieSnap uses advanced AI to analyze food photos, instantly providing accurate nutritional information.
          </p>
          
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            className="btn-primary w-full"
            onClick={onGetStarted}
          >
            Get Started
          </motion.button>
        </div>
      </motion.div>

      <motion.div 
        className="mt-12 text-center text-gray-600 text-sm"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
      >
        <p>No account needed. No data stored.</p>
        <p className="mt-2">Instantly analyze what's on your plate.</p>
      </motion.div>
    </div>
  );
}

export default LandingScreen;