import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const loadingMessages = [
  "Counting your calories...",
  "Analyzing ingredients...",
  "Calculating nutritional value...",
  "Identifying your meal...",
  "Processing your food...",
];

function LoadingState() {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex((prev) => (prev + 1) % loadingMessages.length);
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const spinTransition = {
    loop: Infinity,
    ease: "linear",
    duration: 1
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4">
      <div className="text-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={spinTransition}
          className="w-16 h-16 mx-auto mb-8"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="text-primary-600" viewBox="0 0 24 24">
            <path 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2"
              strokeLinecap="round"
              d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10"
            />
          </svg>
        </motion.div>
        
        <motion.h2
          key={messageIndex}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.5 }}
          className="text-xl font-medium text-gray-800"
        >
          {loadingMessages[messageIndex]}
        </motion.h2>
        
        <motion.div 
          className="mt-6 w-48 h-2 bg-gray-200 rounded-full overflow-hidden mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <motion.div
            className="h-full bg-primary-500 rounded-full"
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 2.5, repeat: Infinity }}
          />
        </motion.div>
      </div>
    </div>
  );
}

export default LoadingState;